import socket


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('',9090))

s.listen()
server_name = "clean_bot_server"


def AppRead():
	connectionSock, addr = s.accept()
	
	msg = connectionSock.recv(1024)
	data = msg.decode().split()
	#print(data)
	recv_data = data[len(data) - 1]
	#print(recv_data)
	return recv_data


								
			
if __name__ == '__main__':
	try:
		while 1:
			data = AppRead()
			print(data)
	except KeyboardInterrupt:
		s.close()
	except Exception as e:
		print(e)
		s.close()
		
