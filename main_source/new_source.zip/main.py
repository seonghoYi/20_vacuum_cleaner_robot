import ctypes
import serial
import pylibi2c
import Jetson.GPIO as GPIO
from time import time, sleep
import threading
import cv2
import socket

import cruiz


AVR_INT = 11
AVR_RST = 13


lock_emotion_state = threading.Lock()
lock_code = threading.Lock()

#const
emotion_state = 0
normal_speed = 100
normal_Lspeed = 100
normal_Rspeed = 110
slow_speed = 80
slow_Lspeed = 80
slow_Rspeed = 90


#global scope
angle = 0
code = ''
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('',9090))
s.listen()

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(AVR_RST, GPIO.OUT)
GPIO.setup(AVR_INT, GPIO.IN)


i2c = pylibi2c.I2CDevice('/dev/i2c-0', 0x40)

def SysInit():
	global s
	print("Initializing device. Please don't move device.")
	GPIO.output(AVR_RST, 0) #AVR Reset
	sleep(0.2)
	GPIO.output(AVR_RST, 1)
	cruiz.CRUIZ_reset()
	sleep(4)
	print("Initializing complete")
	
def getINTstatus():
	data = i2c.ioctl_read(0x40, 1)
	return data
	
	
def SuctionOn():
	i2c.ioctl_write(0x01, bytes([0x00]))
	
def SuctionOff():
	i2c.ioctl_write(0x00, bytes([0x00]))
	
def BT_AT(mode):
	if mode == 0:
		i2c.ioctl_write(0x22, bytes([0x00]))
	elif mode == 1:
		i2c.ioctl_write(0x23, bytes([0x00]))

def BT_tx(data):
	i2c.ioctl_write(0x20, bytes([data]))
	
def BT_rx():
	data = i2c.ioctl_read(0x21, 1)
	return data

def BT_txAxis(count):
	Xlow = count[0] & 0xFF
	Xhigh = (count[0] >> 8) & 0xFF
	Ylow = count[1] & 0xFF
	Yhigh = (count[1] >> 8) & 0xFF
	BT_tx(Xhigh)
	sleep(0.1)
	BT_tx(Xlow)
	sleep(0.1)
	BT_tx(Yhigh)
	sleep(0.1)
	BT_tx(Ylow)
	sleep(0.1)

def PSDRead():
	psd = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
	psd[0] = int.from_bytes(i2c.ioctl_read(0x10, 1), 'big') #psdraw0
	psd[1] = int.from_bytes(i2c.ioctl_read(0x11, 1), 'big') 
	psd[2] = int.from_bytes(i2c.ioctl_read(0x12, 1), 'big') 
	psd[3] = int.from_bytes(i2c.ioctl_read(0x13, 1), 'big') 
	psd[4] = int.from_bytes(i2c.ioctl_read(0x14, 1), 'big') 
	psd[5] = int.from_bytes(i2c.ioctl_read(0x15, 1), 'big') 
	
	psd[6] = int.from_bytes(i2c.ioctl_read(0x16, 1), 'big')  #psdthr0
	psd[7] = int.from_bytes(i2c.ioctl_read(0x17, 1), 'big') 
	psd[8] = int.from_bytes(i2c.ioctl_read(0x18, 1), 'big') 
	psd[9] = int.from_bytes(i2c.ioctl_read(0x19, 1), 'big') 
	psd[10] = int.from_bytes(i2c.ioctl_read(0x1A, 1), 'big') 

	return psd

def StepTarget(target):
	target_H = (target >> 8) & 0xFF
	target_L = (target) & 0xFF
	i2c.ioctl_write(0x39, bytes([target_H]))
	i2c.ioctl_write(0x3A, bytes([target_L]))

def StepSpeed(L_speed, R_speed):
	i2c.ioctl_write(0x33, bytes([L_speed]))
	i2c.ioctl_write(0x34, bytes([R_speed]))
	
def StepConfig(count, direction, L_dir, R_dir):
	Odata = (count & 0x01) << 4
	Odata |= (direction & 0x03) << 2
	Odata |= (R_dir & 0x01) << 1
	Odata |= L_dir & 0x01
	i2c.ioctl_write(0x30, bytes([Odata])) 

def StepStart(L_speed, R_speed, L_dir, R_dir, cnt_toggle, direct, target):
	StepConfig(cnt_toggle, direct, L_dir, R_dir)
	StepSpeed(L_speed, R_speed)
	StepTarget(target)

	i2c.ioctl_write(0x31, bytes([0x00]))
	
def StepStop():
	i2c.ioctl_write(0x32, bytes([0x00]))
	
def StepCount():
	count = [0, 0]
	
	dataH = i2c.ioctl_read(0x35, 1)
	dataL = i2c.ioctl_read(0x36, 1)
	count[0] = (int.from_bytes(dataH, 'big') << 8) | int.from_bytes(dataL, 'big')

	if count[0] & 0x8000:
		count[0] = -(~(count[0] - 1) & 0xFFFF)
	
	dataH = i2c.ioctl_read(0x37, 1)
	dataL = i2c.ioctl_read(0x38, 1)
	count[1] = (int.from_bytes(dataH, 'big') << 8) | int.from_bytes(dataL, 'big')
	
	if count[1] & 0x8000:
		count[1] = -(~(count[1] - 1) & 0xFFFF)
	
	return count

def StepRevision(angle, mov_dir, mov_toward):
	if mov_dir == "horizon_pos" and mov_toward == "forward":
		if angle > 100:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		elif angle < -100:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "horizon_pos" and mov_toward == "backward":
		if angle > 100:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		elif angle < -100:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "vertical_pos" and mov_toward == "forward":
		if angle < -9100:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		elif angle > -8900:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "vertical_pos" and mov_toward == "backward":
		if angle < -9100:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		elif angle > -8900:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "horizon_neg" and mov_toward == "forward":
		if angle < 17900 and angle < 17999 and angle >= 0:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		elif angle > -17900 and angle > -17999 and angle <= 0:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "horizon_neg" and mov_toward == "backward":
		if angle < 17900 and angle < 17999 and angle >= 0:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		elif angle > -17900 and angle > -17999 and angle <= 0:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "vertical_neg" and mov_toward == "forward":
		if angle > 9100:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		elif angle < 8900:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)
	elif mov_dir == "vertical_neg" and mov_toward == "backward":
		if angle > 9100:
			StepSpeed(normal_Lspeed, slow_Rspeed)
		elif angle < 8900:
			StepSpeed(slow_Lspeed, normal_Rspeed)
		else:
			StepSpeed(normal_Lspeed, normal_Rspeed)

def emotion():
	imgpath = './resources/'
	global emotion_state
	emotion = 0
	old_emotion = 0
	try:
		i = 0
		cv2.namedWindow('emotion', cv2.WINDOW_NORMAL)
		cv2.setWindowProperty('emotion', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
		while 1:
			lock_emotion_state.acquire()
			try:
				old_emotion = emotion
				emotion = emotion_state
			finally:
				lock_emotion_state.release()
			if old_emotion != emotion:
				i = 0
			if emotion == 0:
				img = cv2.imread(imgpath + 'lidar_mode/' + str(i) + '.jpg')
				i += 1
				if i > 7:
					i = 0
			elif emotion == 1:
				img = cv2.imread(imgpath + 'face_emotion/big_smile/' + 'big_smile' + str(i) + '.jpg')
				i += 1
				if i > 6:
					i = 0
			cv2.imshow('emotion', img)
			
			k = cv2.waitKey(1) & 0xFF
			if k == 27:
				break
			sleep(0.3)
		cv2.destroyAllWindows()
		
	except KeyboardInterrupt:
		cv2.destroyAllWindows()
	except Exception as e:
		cv2.destroyAllWindows()
		print(e)

def msg_server():
	global s, code
	while 1:
		connectionSock, addr = s.accept()
		msg = connectionSock.recv(1024)
		data = msg.decode().split()
		#print(data)
		recv_data = data[len(data) - 1]
		#print(recv_data)
		
		code = recv_data
		print('msg: ',code)
		recv_data = ''



def main():
	global angle, code

	SysInit()

	mode = "AutoOn"  # "AutoOff"
	start = 1
	send_axis = [0, 0]
	OBJECT = 30
	OBJECT1 = 31
	OBJECT2 = 32
	FINISH1 = 41
	FINISH2 = 42
	FINISH3 = 43
	FINISH4 = 44
	FINISH5 = 45

	CAN = 100
	PAPER = 200
	PLASTIC = 300

	wall = False
	is_turning = False
	turn_toggle = 0
	mov_dir = "horizon_pos"
	mov_toward = "forward"
	turn_flag = 0
	flag = 0
	obj_flag = -1
	revision_flag = False
	mov_target_flag = False

	std_x = 0 #경기장 크기
	std_y = 0 #경기장 크기


	psd_wall_threshold = 70
	psd_obj_threshold = 100

	while True:
		lock_code.acquire()
		try:
			command = code
			if command == "AutoOn" or command == "AutoOff" or command == "ManualOn" or command == "ManualOff":
				start = command
				command = 0
				code = 0
		finally:
			lock_code.release()

		if mode == "AutoOn":
			angle = cruiz.CRUIZ_rx()
			if angle != None:
				if flag == 2:
					if turn_toggle == 0: #오른쪽에서 돌때 1
						if angle < -8700 and angle > -9100:
							StepStop()
							flag = 3
					elif turn_toggle == 1: #왼쪽에서 돌때 1
						if angle < -8900 and angle > -9300:
							StepStop()
							flag = 3
				elif flag == 5:
					if turn_toggle == 0: #오른쪽에서 돌때 2
						if angle < -17700 and angle > -17999 or angle > 17900 and angle < 17999:
							StepStop()
							turn_toggle = 1
							flag = 6
					elif turn_toggle == 1: #왼쪽에서 돌때 2
						if angle < 100 and angle > -300:
							StepStop()
							turn_toggle = 0
							flag = 0
				elif flag == OBJECT: #obj found heading to obj
					if obj_flag == 0:
						StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 400)
						mov_target_flag = True
						revision_flag = True
					elif obj_flag == 1:
						StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 400)
						mov_target_flag = True
						revision_flag = True
					elif obj_flag == 2:
						StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 400)
						mov_target_flag = True
						revision_flag = True
					elif obj_flag == 3:
						StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 400)
						mov_target_flag = True
						revision_flag = True
					elif obj_flag == 4:
						StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 400)
						mov_target_flag = True
						revision_flag = True
					elif obj_flag == 5:
						StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 400)
						mov_target_flag = True
						revision_flag = True
					flag = OBJECT1
					obj_flag = -1

				elif flag == 10: #경기장 끝까지 왔을 때
					if turn_toggle == 0:
						if angle < -17700 and angle > -17999 or angle > 17900 and angle < 17999:
							StepStop()
							turn_toggle = 1
							flag = FINISH1
					elif turn_toggle == 1:
						if angle < 100 and angle > -300:
							StepStop()
							turn_toggle = 0
							flag = FINISH1

				elif flag == 11: #경기장 끝에서 중심으로 왔을 때
					if turn_toggle == 0:
						if angle < 9100 and angle > 8700:
							StepStop()
							turn_toggle = 1
							flag = FINISH3
					elif turn_toggle == 1:
						if angle < 9300 and angle > 8900:
							StepStop()
							turn_toggle = 0
							flag = FINISH3
				elif flag == 12: #경기장 끝 y에서 시작점 y에 도착했을 때
					if angle < 300 and angle > -100:
						StepStop()
						flag = FINISH5

				if revision_flag == True:
					StepRevision(angle, mov_dir, mov_toward)

			if flag == 1 or flag == 3:
				psd = PSDRead()
				if psd[0] >= psd_wall_threshold:
					psd = PSDRead()
					if psd[0] >= psd_obj_threshold:
						print(psd, 'psd: 0 obj')
						StepStop()
						revision_flag = False
						count = StepCount()
						if mov_dir == "horizon_pos":
							count[1] += 135 #수정해야됨
						elif mov_dir == "horizon_neg":
							count[1] -= 135
						send_axis = [count[0], count[1]]
						StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						flag = OBJECT
						obj_flag = 0

				elif psd[1] >= psd_wall_threshold:
					psd = PSDRead()
					if psd[2] >= psd_wall_threshold and psd[3] >= psd_wall_threshold:
						print(psd, 'psd: 1 wall')
						StepStop()
						revision_flag = False
						if turn_toggle == 0:
							count = StepCount()
							std_x = count[0]
							StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						elif turn_toggle == 1:
							StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = 2
					elif psd[1] >= psd_obj_threshold:
						print(psd, 'psd: 1 obj')
						StepStop()
						revision_flag = False
						count = StepCount()
						if mov_dir == "horizon_pos":
							count[1] += 135 #수정해야됨
						elif mov_dir == "horizon_neg":
							count[1] -= 135
						send_axis = [count[0], count[1]]
						StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						flag = OBJECT
						obj_flag = 1

				elif psd[2] >= psd_wall_threshold:
					psd = PSDRead()
					if psd[1] >= psd_wall_threshold and psd[3] >= psd_wall_threshold:
						print(psd, 'psd: 2 wall')
						StepStop()
						revision_flag = False
						if turn_toggle == 0:
							std_x = count[0]
							StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						elif turn_toggle == 1:
							StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = 2
					elif psd[2] >= psd_obj_threshold:
						print(psd, 'psd: 2 obj')
						StepStop()
						revision_flag = False
						count = StepCount()
						if mov_dir == "horizon_pos":
							count[1] += 135 #수정해야됨
						elif mov_dir == "horizon_neg":
							count[1] -= 135
						send_axis = [count[0], count[1]]
						StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						flag = OBJECT
						obj_flag = 2

				elif psd[3] >= psd_wall_threshold:
					psd = PSDRead()
					if psd[2] >= psd_wall_threshold and psd[4] >= psd_wall_threshold:
						print(psd, 'psd: 3 wall')
						StepStop()
						revision_flag = False
						if turn_toggle == 0:
							std_x = count[0]
							StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						elif turn_toggle == 1:
							StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = 2
					elif psd[3] >= psd_obj_threshold:
						print(psd, 'psd: 3 obj')
						StepStop()
						revision_flag = False
						count = StepCount()
						if mov_dir == "horizon_pos":
							count[1] += 135 #수정해야됨
						elif mov_dir == "horizon_neg":
							count[1] -= 135
						send_axis = [count[0], count[1]]
						StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = OBJECT
						obj_flag = 3

				elif psd[4] >= psd_wall_threshold:
					psd = PSDRead()
					if psd[2] >= psd_wall_threshold and psd[3] >= psd_wall_threshold:
						print(psd, 'psd: 4 wall')
						StepStop()
						revision_flag = False
						if turn_toggle == 0:
							std_x = count[0]
							StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						elif turn_toggle == 1:
							StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = 2
					elif psd[4] >= psd_obj_threshold:
						print(psd, 'psd: 4 obj')
						StepStop()
						revision_flag = False
						count = StepCount()
						if mov_dir == "horizon_pos":
							count[1] += 135 #수정해야됨
						elif mov_dir == "horizon_neg":
							count[1] -= 135
						send_axis = [count[0], count[1]]
						StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = OBJECT
						obj_flag = 4

				elif psd[5] >= psd_wall_threshold:
					psd = PSDRead()
					if psd[5] >= psd_obj_threshold:
						print(psd, 'psd: 5 obj')
						StepStop()
						revision_flag = False
						count = StepCount()
						if mov_dir == "horizon_pos":
							count[1] += 135 #수정해야됨
						elif mov_dir == "horizon_neg":
							count[1] -= 135
						send_axis = [count[0], count[1]]
						StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = OBJECT
						obj_flag = 5


			if start == 1 and mov_target_flag == False:
				if flag == 0: #advance horizon
					mov_dir = "horizon_pos"
					mov_toward = "forward"
					StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 1, 0, 0)
					revision_flag = True
					flag = 1
				elif flag == 3: #advance vertical
					mov_dir = "vertical_pos"
					mov_toward = "forward"
					StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 1, 3, 400)
					mov_target_flag = True
					revision_flag = True
					flag = 4
				elif flag == 6: #advance inverse horizon
					mov_dir = "horizon_neg"
					mov_toward = "forward"
					StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 2, 0, 0)
					revision_flag = True
					flag = 1
				elif flag == OBJECT1:
					data = CAN
					found_dir = 0

					if mov_dir == "horizon_pos":
						found_dir = 0
					elif mov_dir == "horizon_neg":
						found_dir = 1
					elif mov_dir == "vertical_pos":
						found_dir = 2
					elif mov_dir == "vertical_neg":
						found_dir = 3

					BT_txAxis(send_axis)
					BT_tx(found_dir)
					BT_tx(data)

					flag = OBJECT2

				elif flag == OBJECT2:
					if GPIO.input(AVR_INT) == 1:
						data = getINTstatus()
						if data == b'\x01':
							data = BT_rx()
							if data == b'\xFF':
								if mov_dir == "horizon_pos" and mov_toward == "forward":
									flag = 0
								elif mov_dir == "horizon_neg" and mov_toward == "forward":
									flag = 6
						else:
							print('error')

				elif flag == FINISH1:
					std_x_center = std_x // 2
					if turn_toggle == 0:
						mov_dir = "horizon_pos"
						mov_toward = "forward"
						StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 1, 0, std_x_center)
						mov_target_flag = True
						revision_flag = True
					elif turn_toggle == 1:
						mov_dir = "horizon_neg"
						mov_toward = "forward"
						StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 1, 3, std_x_center)
						mov_target_flag = True
						revision_flag = True
					flag = FINISH2

				elif flag == FINISH3:
					mov_dir = "vertical_neg"
					mov_toward = "forward"
					StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 1, 2, std_y)
					flag = FINISH4

				elif flag == FINISH5:
					mov_dir = "horizon_pos"
					mov_toward = "backward"
					StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 1, 0, std_x_center)
					mov_target_flag = True
					revision_flag = True
					flag = FINISH6


			if mov_target_flag == True:
				if GPIO.input(AVR_INT) == 1:
					data = getINTstatus()
					if data == b'\x02':
						print('complete')
						mov_target_flag = False
						revision_flag = False
						if flag == 4:
							if turn_toggle == 0:
								StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
							elif turn_toggle == 1:
								StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
							flag = 5
						elif flag == FINISH2:
							if turn_toggle == 0:
								StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
							elif turn_toggle == 1:
								StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
							flag = 11
						elif flag == FINISH4:
							StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
							flag = 12
						elif flag == FINISH6:
							mode = "AutoOff"

					elif data == b'\x03':
						print('interrupted')
						count = StepCount()
						std_y = count[1]
						mov_target_flag = False
						revision_flag = False
						if turn_toggle == 0:
							StepStart(normal_Lspeed, normal_Rspeed, 1, 0, 0, 0, 0)
						elif turn_toggle == 1:
							StepStart(normal_Lspeed, normal_Rspeed, 0, 1, 0, 0, 0)
						flag = 10

		elif mode == "ManualOn":
			lock_code.acquire()
			try:
				command = code
			finally:
				lock_code.release()
			if command == "Forward":
				print('forward')
				StepStart(normal_Lspeed, normal_Rspeed, 0, 0, 0, 0, 0)
				command = ''
				code = ''
			if command == "Right":
				print('Right')
				StepStart(normal_speed, normal_speed, 0, 1, 0, 0, 0)
				pass
			if command == "Backward":
				print('Backward')
				StepStart(normal_Lspeed, normal_Rspeed, 1, 1, 0, 0, 0)
				command = ''
				code = ''
			if command == "Left":
				print('Left')
				StepStart(normal_speed, normal_speed, 1, 0, 0, 0, 0)
				command = ''
				code = ''
			if command == "FLeft":
				print('FLeft')
				StepStart(90, normal_speed, 0, 0, 0, 0, 0)
				command = ''
				code = ''
			if command == "FRight":
				print('FRight')
				StepStart(normal_speed, 90, 0, 0, 0, 0, 0)
				command = ''
				code = ''
			if command == "BRight":
				print('BRight')
				StepStart(normal_speed, 90, 1, 1, 0, 0, 0)
				command = ''
				code = ''
			if command == "BLeft":
				print('BLeft')
				StepStart(90, normal_speed, 1, 1, 0, 0, 0)
				command = ''
				code = ''
			if command == "stop":
				print('stop')
				StepStop()
				command = ''
				code = ''

		elif mode == "AutoOff" or mode == "ManualOff":
			start = 1
			send_axis = [0, 0]
			OBJECT = 30
			OBJECT1 = 31
			OBJECT2 = 32
			FINISH1 = 41
			FINISH2 = 42
			FINISH3 = 43
			FINISH4 = 44
			FINISH5 = 45

			CAN = 100
			PAPER = 200
			PLASTIC = 300
			wall = False
			is_turning = False
			turn_toggle = 0
			mov_dir = "horizon_pos"
			mov_toward = "forward"
			turn_flag = 0
			flag = 0
			obj_flag = -1
			revision_flag = False
			mov_target_flag = False

			std_x = 0  # 경기장 크기
			std_y = 0  # 경기장 크기

if __name__ == '__main__':
	#display_thread = threading.Thread(target=emotion, args = (), daemon = True)
	#display_thread.start()
	main_thread = threading.Thread(target=main, args = ())
	msg_thread = threading.Thread(target=msg_server, args = (), daemon = True)
	main_thread.start()
	msg_thread.start()
	'''
	SysInit()
	while 1:
		if GPIO.input(AVR_INT) == 1:
			data = getINTstatus()
			if data == b'\x01':
				data = BT_rx()
				print(data)
				if data == b'A':
					print('a')
					StepStart(120, 120, 0, 0, 1, 0, 0)
					sleep(1)
					StepStop()
					break
					
	count = StepCount()
	print(count)
	BT_txAxis(count)
	'''
	'''
	SysInit()
	StepStart(120, 120, 0, 0, 1, 0, 400)
	'''
	
	'''
	SysInit()
	SuctionOn()
	StepStart(120, 120, 0, 0, 1, 0, 400)
	sleep(0.1)
	StepStop()
	while 1:
		if GPIO.input(AVR_INT) == 1:
			data = getINTstatus()
			if data == b'\x02':
				print('complete')
				break
			elif data == b'\x03':
				print('interrupted')
				break
	count = StepCount()
	print(count)
	#StepStop()
	sleep(1)
	StepStart(120, 120, 0, 0, 1, 0, 400)
	while 1:
		if GPIO.input(AVR_INT) == 1:
			data = getINTstatus()
			if data == b'\x02':
				print('complete')
				break
			elif data == b'\x03':
				print('interrupted')
				break
	count = StepCount()
	print(count)
	#StepStop()
	SuctionOff()
	'''
	'''
	SysInit()
	while 1:
		SuctionOn()
		sleep(2)
		SuctionOff()
		sleep(2)
	'''
