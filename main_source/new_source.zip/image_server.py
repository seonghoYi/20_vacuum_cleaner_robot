import cv2
from PIL import Image
import numpy as np
from nanocamera import Camera
from flask import Flask, Response
from time import sleep, time


'''
if camera.isReady() == False:
	print('camera disconnected error')
'''
	
def CameraGet():
	while 1:
		'''
		frame = camera.read()
		cv2.imwrite('./resources/streaming_data/camera/cam.jpeg', frame)
		img_file = open('./resources/streaming_data/camera/cam.jpeg', 'rb').read()
		'''
		try:
			img_file = open('./resources/streaming_data/camera/cam.jpeg', 'rb').read()
		finally:
			yield (b'--frame\r\n'
						b'Content-Type: image/jpeg\r\n\r\n' + bytes(img_file) + b'\r\n')
					
					

app = Flask(__name__)

@app.route('/')
def hello_world():
	return 'Hello World!'




@app.route('/lidar')
def ShowLidar():
	 return 'No implementaion yet'

@app.route('/camera')
def ShowCamera():
	while 1:
		return Response(gen(),
								mimetype='multipart/x-mixed-replace; boundary=frame')

def gen():
	camera = Camera(width=500, height=300, fps = 30)
	
	while True:
		img = camera.read()
		
		frame = cv2.imencode('.jpg', img)[1].tobytes()
		yield (b'--frame\r\n'
						b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
	
	
	
def run():
	app.run(host = '0.0.0.0', port = 6060, debug=True, threaded=True)

if __name__ == '__main__':
	run()
	#cam_thread = threading.Thread(target=CameraGet, args = ())
	#cam_thread.start()
	#CameraGet()
