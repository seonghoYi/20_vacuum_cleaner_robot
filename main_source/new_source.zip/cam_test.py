import cv2
import numpy as np
from PIL import Image
from nanocamera import Camera
from time import sleep, time

import tf

camera = Camera(width=224, height=224, fps = 30)

data = 0
def CameraGet():
	img = camera.read()
	img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
	img = Image.fromarray(img)
	probability = tf.check(img)
	return (probability[0,0], probability[0,1], probability[0,2])


if __name__ == '__main__':
	while True:
		start = time()
		print('can: {0:.3f}, paper: {1:.3f}, plastic: {2:.3f}'.format(i[0], i[1], i[2]))
		print(time() - start)
